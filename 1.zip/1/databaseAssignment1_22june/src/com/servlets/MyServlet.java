package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MyServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		ServletContext context = getServletContext();
		Connection conn = (Connection) context.getAttribute("Connection");
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("select * from student");
			out.println("<html><body>");
			out.println("<table style=\"border:  1px solid black\">");
			while (rs.next()) {
				out.println("<tr style=\"border:  1px solid black\">");

				out.println("<td  style=\"border:  1px solid black\">");
				out.println(rs.getInt(1));
				out.println("</td>");

				out.println("<td  style=\"border:  1px solid black\">");
				out.println(rs.getString(2));
				out.println("</td>");

				out.println("<td  style=\"border:  1px solid black\">");
				out.println(rs.getInt(3));
				out.println("</td>");
				out.println("</tr>");

			}
			out.println("</table>");
			out.println("</html></body>");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
