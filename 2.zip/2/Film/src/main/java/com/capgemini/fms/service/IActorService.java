package com.capgemini.fms.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.fms.bean.Actor;

public interface IActorService {

	public Actor addActor(HashMap mapActor);

	public List<Actor> searchByName(String firstName, String lastName);

	public String modifyActor(HashMap actor);

	public String deleteActor(String firstName, String lastName);

}
