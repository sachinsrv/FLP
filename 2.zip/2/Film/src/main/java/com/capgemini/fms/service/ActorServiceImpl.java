package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;

import com.capgemini.fms.bean.Actor;
import com.capgemini.fms.bean.Album;
import com.capgemini.fms.bean.Category;
import com.capgemini.fms.bean.Film;
import com.capgemini.fms.bean.Image;
import com.capgemini.fms.dao.ActorDAOImpl;
import com.capgemini.fms.dao.FilmDAOImpl;
import com.capgemini.fms.service.IActorService;

public class ActorServiceImpl implements IActorService {

	private ActorDAOImpl actorDAO;
	private FilmDAOImpl filmDAO;
	protected EntityManager em;
	private Category category;

	public ActorServiceImpl(ActorDAOImpl actorDAO) {
		this.actorDAO = actorDAO;
	}

	public ActorServiceImpl(EntityManager em) {
		filmDAO = new FilmDAOImpl(em);
		actorDAO = new ActorDAOImpl(em);
	}

	public Actor addActor(HashMap mapActor) {
		if (mapActor == null) {
			throw new NullPointerException();

		} else {

			try {

				Actor actor = new Actor();
				actor.setFirstName((String) mapActor.get("firstName"));
				actor.setLastName((String) mapActor.get("lastName"));
				actor.setGender((String) mapActor.get("gender"));
				List<Image> imgList = new ArrayList<Image>();
				for (String image : (List<String>) mapActor.get("actorImg")) {
					Image im = new Image();
					im.setUrl(image);
					im.setCreateDate((Date) mapActor.get("createDate"));
					imgList.add(im);
					im = actorDAO.addImage(im);
				}

				Album album = new Album();
				album.setName((String) mapActor.get("albumName"));
				album.setCreateDate((Date) mapActor.get("createDate"));
				album.setImage(imgList);
				actorDAO.addAlbum(album);
				actor.setAlbum(album);
				List<Category> categoryList = new ArrayList<Category>();

				List<Film> list = new ArrayList<Film>();
				for (HashMap filmMap : (List<HashMap>) mapActor.get("filmList")) {

					List<HashMap> categoryMap = (List<HashMap>) filmMap.get("categories");

					for (HashMap m : categoryMap) {

						Category newCategory = new Category();
						newCategory.setName((String) m.get("name"));
						newCategory.setCreateDate((Date) filmMap.get("createDate"));
						category = filmDAO.addCategory(newCategory);
						categoryList.add(category);

					}

					Film film = new Film();
					film.setTitle((String) filmMap.get("title"));
					film.setLanguage((String) filmMap.get("language"));

					film.setDescription((String) filmMap.get("description"));
					byte b = ((Integer) filmMap.get("rating")).byteValue();
					film.setRating(b);
					film.setReleaseYear(((Integer) filmMap.get("releaseYear")).intValue());
					film.setLength(((Integer) filmMap.get("length")).shortValue());
					film.setCreateDate((Date) filmMap.get("createDate"));

					film.setCategory(categoryList);
					film.setAlbum(album);

					film = filmDAO.save(film);

					list.add(film);
				}
				actor.setFilm(list);
				actor.setCreateDate((Date) mapActor.get("createDate"));
				actor = actorDAO.save(actor);
				for (Film film : list) {
					filmDAO.setActorOnFilm(film.getId(), actor);
				}

				return actor;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	public String modifyActor(HashMap mapActor) {

		if (mapActor.equals(null)) {
			throw new NullPointerException();

		} else {
			try {

				List<Actor> savedActorList = actorDAO.searchByName((String) mapActor.get("firstName"),
						(String) mapActor.get("lastName"));
				for (Actor actor : savedActorList) {

					List<Image> imgList = new ArrayList<Image>();
					for (String url : (List<String>) mapActor.get("actorImg")) {
						Image image = new Image();
						image.setCreateDate((Date) mapActor.get("createDate"));
						actorDAO.addImage(image);
						imgList.add(image);
					}
					Album album = new Album();
					album.setName((String) mapActor.get("album"));
					album.setCreateDate((Date) mapActor.get("createDate"));
					album.setImage(imgList);

					List<Category> categoryList = new ArrayList<Category>();
					List<Film> list = new ArrayList<Film>();
					for (HashMap filmMap : (List<HashMap>) mapActor.get("filmList")) {

						List<HashMap> categoryMap = (List<HashMap>) filmMap.get("categories");

						for (HashMap m : categoryMap) {

							Category newCategory = new Category();
							newCategory.setName((String) m.get("name"));
							newCategory.setCreateDate((Date) filmMap.get("createDate"));
							category = filmDAO.addCategory(newCategory);
							categoryList.add(category);

						}

						Film film = new Film();
						film.setTitle((String) filmMap.get("title"));
						film.setLanguage((String) filmMap.get("language"));

						film.setDescription((String) filmMap.get("description"));
						byte b = ((Integer) filmMap.get("rating")).byteValue();
						film.setRating(b);
						film.setReleaseYear(((Integer) filmMap.get("releaseYear")).intValue());
						film.setLength(((Integer) filmMap.get("length")).shortValue());
						film.setCreateDate((Date) filmMap.get("createDate"));

						film.setCategory(categoryList);
						film.setAlbum(album);

						film = filmDAO.save(film);
						list.add(film);
					}

					actor.setFirstName((String) mapActor.get("firstName"));
					actor.setLastName((String) mapActor.get("lastName"));
					actor.setGender((String) mapActor.get("gender"));
					actor.setCreateDate((Date) mapActor.get("createDate"));
					actor.setAlbum(album);
					actor.setFilm(list);

					int id = actor.getId();

					actorDAO.modifyActor(id, actor);

					for (Film film : list) {
						System.out.println("title:  " + film.getTitle());
						filmDAO.setActorOnFilm(film.getId(), actor);
					}
					return "updated";

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public String deleteActor(String firstName, String lastName) {
		if (firstName.equals(null) && lastName.equals(null)) {
			throw new NullPointerException();
		} else {
			try {
				if (actorDAO.deleteActor(firstName, lastName))
					return "deleted";
				return "input not present";
			} catch (Exception e) {
				return "error";
			}

		}
	}

	public List<Actor> searchByName(String firstName, String lastName) {
		List<Actor> l = null;
		if (firstName.equals(null) || lastName.equals(null))
			throw new NullPointerException();
		try {
			l = actorDAO.searchByName(firstName, lastName);
			if (!l.isEmpty()) {
				return l;
			}
		} catch (Exception e) {
		}

		{
			return null;
		}
	}

}
