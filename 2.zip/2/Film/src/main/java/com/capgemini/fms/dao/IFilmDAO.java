package com.capgemini.fms.dao;

import java.util.List;

import com.capgemini.fms.bean.Film;

public interface IFilmDAO {

	public Film save(Film film);

	public List<Film> searchByTitle(String title);

	public List<Film> searchByLanguage(String language);

	public List<Film> searchByReleaseYear(int year);

	public List<Film> searchByCategory(String category);

	public List<Film> searchByActor(String actor);

	public List<Film> searchByRating(byte rating);

	public Boolean modifyFilm(int id,Film film);

	public Boolean deleteFilm(String title);

}
