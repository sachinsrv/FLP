package com.capgemini.fms.view;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.fms.pojo.Actor;
import com.capgemini.fms.pojo.Film;



public class BootClass {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("hello");
		EntityManager em = emf.createEntityManager();
		Actor actor=new Actor();
		Film film=new Film();
		em.getTransaction().begin();
		film.setId(1);
		film.setTitle("sholay");
		film.setAlbum(null);
		/*film.setReleaseYear(null);*/
		film.setLanguage("hindi");
		film.setActor(null);
		film.setCategory(null);
		film.setRating((byte)4);
		film.setDeleteDate(null);
		film.setLength((short)180);
		film.setCreateDate(null);
		em.persist(film);
		em.getTransaction().commit();
		em.getTransaction().begin();
		actor.setId(1);
		actor.setFirstName("amitabh");
		actor.setLastName("bachhan");
		actor.setGender("male");
		actor.setAlbum(null);
		actor.setFilm(null);
		em.persist(actor);
		em.getTransaction().commit();
		System.out.println("Persisted "+actor);
		
		em.close();
		emf.close();
		
	}

}

