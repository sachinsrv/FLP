package com.capgemini.fms.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.capgemini.fms.pojo.Actor;

public class ActorRepositoryImpl implements IActorRepository{
	private EntityManager em;
	
	public ActorRepositoryImpl(EntityManager em) {
		this.em = em;
	}

	public Actor save(Actor actor) {
		try{
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a where a.firstName like :nam", Actor.class);
			Actor ac = query.setParameter("nam", actor.getFirstName()).getSingleResult();
			
			if(ac==null){
				em.persist(actor);
				return actor;
			}
			else return ac;
			}
			catch(NoResultException e){
				em.persist(actor);
				return actor;
			}
	}
	

public List<Actor> searchByName(String firstName, String lastName) {
		
		TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l", Actor.class);
		List<Actor> list = query.setParameter("f", firstName).setParameter("l", lastName).getResultList();
		return list;
		
	}

	public boolean remove(String name) {
		try{
			TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l", Actor.class);
			Actor actor = query.setParameter("f", firstName).setParameter("l", lastName).getSingleResult();
			actor.setDeleteDate(new Date());
			em.persist(actor);
			return true;
			}catch(Exception e){return false;}
	}

	public boolean updateActor(Actor actor) {
		Actor savedActor =em.find(null, null);
		savedActor.setAlbum(actor.getAlbum());
		savedActor.setFirstName(actor.getFirstName());
		savedActor.setLastName(actor.getLastName());
		savedActor.setGender(actor.getGender());
		savedActor.setCreateDate(actor.getCreateDate());
		savedActor.setFilm(actor.getFilm());
		em.persist(actor);
		return true;
	}

	public List<Actor> searchActorByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
