package com.capgemini.fms.service;

import java.util.Date;
import java.util.List;

import com.capgemini.fms.pojo.Actor;
import com.capgemini.fms.pojo.Album;
import com.capgemini.fms.pojo.Category;
import com.capgemini.fms.pojo.Film;

public interface IFilmService {
	
	public String addFilm(Film film);
	
	public String modifyFilm(Film film);
	
	public String removeFilm(String title);
	
	public List<Film> searchFilmByTitle(String title);
	
	public List<Film> searchFilmByLanguage(String language);
	
	public List<Film> searchFilmByRating(byte rating);
	
	public List<Film> searchFilmByReleaseYear(Date releaseyear);
	
	public List<Film> getAllFilm();
	
	
}
