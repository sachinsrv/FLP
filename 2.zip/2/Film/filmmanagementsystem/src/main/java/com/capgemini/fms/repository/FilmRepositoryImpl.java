package com.capgemini.fms.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.capgemini.fms.pojo.Film;

public class FilmRepositoryImpl implements IFilmRepository{
	private EntityManager em;

	public Film save(Film film) {
		try{
			TypedQuery<Film> query = em.createQuery("Select a from Film a where a.title like :nam", Film.class);
			Film fm = query.setParameter("nam", film.getTitle()).getSingleResult();
			
			if(fm==null){
				em.persist(film);
				return film;
			}
			else return fm;
			}
			catch(NoResultException e){
				em.persist(film);
				return film;
			}
	}

	public List<Film> searchFilmByTitle(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByLanguage(String language) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByRating(byte rating) {
		try {
			/*TypedQuery<Film> query = em.createQuery("SELECT f FROM Film f WHERE f.rating =:r", Film.class);
			List<Film> list = query.setParameter("r", rating).getResultList();
			System.out.println(list);*/
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

	public List<Film> searchFilmByReleaseYear(Date releaseyear) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean remove(String title) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateFilm(Film film) {
		// TODO Auto-generated method stub
		return false;
	}

}
