package com.capgemini.film.test;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.fms.pojo.Film;
import com.capgemini.fms.repository.IFilmRepository;
import com.capgemini.fms.service.IFilmService;
import com.capgemini.fms.service.FilmServiceImpl;

public class FilmServiceTest {
	private IFilmService service;
	
	@Mock private IFilmRepository repo;
	
	
	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		service = new FilmServiceImpl(repo); 
	}
	//AddFilm testcases
	//1.If inputs are valid then it should add data in film.
	@Test
	public void soleIsAnFilm(){
		Film film=new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
		Mockito.when(repo.save((film))).thenReturn(film);
		assertEquals(film, service.addFilm(film));
	}
	
	//2. if any values is not valid then values should not be added
	@Test
	public void invalidData(){
		Film film=new Film(-1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
		Mockito.when(repo.save((film))).thenReturn(null);
		assertEquals(null, service.addFilm(film));
	}
	//3. Even if details are valid it does not add data because of problem in system
	@Test
	public void validDataNotStore(){
		Film film=new Film(-1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
		Mockito.when(repo.save((film))).thenReturn(null);
		assertEquals(null, service.addFilm(film));
	}

	
	//SearchFilmByTitle testcases
	//1.SoleExistInSystem
	public void soleExistsInSystem(){

		Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
		List<Film> filmList=new ArrayList<Film>();
		filmList.add(film);
		Mockito.when(repo.searchFilmByTitle("sole")).thenReturn(filmList);	
		assertEquals(film, service.searchFilmByTitle("sole"));
	}
	//2. If Title is null return exception
	@Test(expected =NullPointerException.class)
	public void nullTitleThenGiveException(){

		Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
		FilmServiceImpl fs=new FilmServiceImpl(repo);
		fs.searchFilmByTitle(null);
	
	}
	//3.Film is not present
		@Test(expected =IllegalArgumentException.class)
		public void filmNotPresent(){

			Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
			FilmServiceImpl fs=new FilmServiceImpl(repo);
			fs.searchFilmByTitle("sol");
		}
		//4.Title is valid but problem in system
		public void problemInSystem(){

			Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
			List<Film> filmList=new ArrayList<Film>();
			filmList.add(film);
			Mockito.when(repo.searchFilmByTitle("sole")).thenReturn(null);
			assertEquals(null, service.searchFilmByTitle("sole"));
		}
		
		//SearchFilmByLanguage testcases
		//1.Hindi Movi Exist In System
		public void HindiFilmExistsInSystem(){

			Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
			List<Film> filmListByLanguage=new ArrayList<Film>();
			filmListByLanguage.add(film);
			Mockito.when(repo.searchFilmByLanguage("hindi")).thenReturn(filmListByLanguage);
			assertEquals(film, service.searchFilmByLanguage("hindi"));
		}
		//2. If Title is null return exception
		@Test(expected =NullPointerException.class)
		public void nullLanguageThenGiveException(){

			Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
			FilmServiceImpl fs=new FilmServiceImpl(repo);
			fs.searchFilmByLanguage(null);
		}
		//3.Film is not present
			@Test(expected =IllegalArgumentException.class)
			public void englishfilmNotPresent(){

				Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
				FilmServiceImpl fs=new FilmServiceImpl(repo);
				fs.searchFilmByLanguage("english");
			}
			//4.Title is valid but problem in system
			public void problemsInSystem(){

				Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
				List<Film> filmList=new ArrayList<Film>();
				filmList.add(film);
				Mockito.when(repo.searchFilmByLanguage("hindi")).thenReturn(null);
				assertEquals(null, service.searchFilmByLanguage("hindi"));
			}
			
			
			//SearchFilmByRating testcases
			//1.Rating 3 film is  Exist In System
			public void Rating3FilmExistsInSystem(){

				Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
				List<Film> filmListByRating=new ArrayList<Film>();
				filmListByRating.add(film);
				Mockito.when(repo.searchFilmByRating((byte)3)).thenReturn(filmListByRating);
				assertEquals(film, service.searchFilmByRating((byte)3));
			}
			//2. If Rating is 0 return exception
			@Test(expected =NullPointerException.class)
			public void IfRatingIs0ThenGiveException(){

				Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
				FilmServiceImpl fs=new FilmServiceImpl(repo);
				fs.searchFilmByRating((byte)0);
			}
			//3.Film is not present with 4 rating
				@Test(expected =IllegalArgumentException.class)
				public void FilmWith4RatingIsNotPresent(){

					Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());	
					FilmServiceImpl fs=new FilmServiceImpl(repo);
					fs.searchFilmByRating((byte)4);
				}
				//4.Title is valid but problem in system
				public void someProblemsInSystem(){

					Film film = new Film(1,"sole","good film",new Date(),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
					List<Film> filmList=new ArrayList<Film>();
					filmList.add(film);
					Mockito.when(repo.searchFilmByRating((byte)3)).thenReturn(null);
					assertEquals(null, service.searchFilmByRating((byte)3));
				}

				
				//SearchFilmByReleaseYear testcases
				//1.  Any film release in year 1990 is  Exist In System
				public void year1990sFilmExistsInSystem(){
					SimpleDateFormat st=new SimpleDateFormat("yyyy-dd-mm");
					String value="1990-02-02";
					Film film;
					try {
						film = new Film(1,"sole","good film",st.parse(value),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
						List<Film> filmLisByReleaseYear=new ArrayList<Film>();
						filmLisByReleaseYear.add(film);
						Mockito.when(repo.searchFilmByReleaseYear((st.parse(value)))).thenReturn(filmLisByReleaseYear);
						assertEquals(film, service.searchFilmByReleaseYear((st.parse(value))));
					} catch (ParseException e) {
						e.printStackTrace();
					}
				}
				//2. If Release year  is not specified return exception
				 
				@Test(expected =NullPointerException.class)
				public void IfReleaseYearIsNotSpecifiedThenGiveException(){
					SimpleDateFormat st=new SimpleDateFormat("yyyy-dd-mm");
					String value="1990-02-02";
					try{
					Film film = new Film(1,"sole","good film",st.parse(value),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
					FilmServiceImpl fs=new FilmServiceImpl(repo);
					fs.searchFilmByReleaseYear(null);
				} catch (ParseException e) {
						e.printStackTrace();
				}
				}
				//3.Film is not present with date 02-02-1990
					@Test(expected =IllegalArgumentException.class)
					public void FilmWithGivendateIsNotPresent(){
						SimpleDateFormat st=new SimpleDateFormat("yyyy-dd-mm");
						String value="1990-02-02";
						String value2="1990-03-02";
						try {
							Film film = new Film(1,"sole","good film",st.parse(value),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
						} catch (ParseException e) {
						
							e.printStackTrace();
						}
						FilmServiceImpl fs=new FilmServiceImpl(repo);
						try {
							fs.searchFilmByReleaseYear((st.parse(value2)));
						} catch (ParseException e) {
								e.printStackTrace();
						}
					}
					//4.Release Year is valid but problem in system
					public void systemProblem(){
						SimpleDateFormat st=new SimpleDateFormat("yyyy-dd-mm");
						String value="1990-02-02";
						Film film;
						try {
							film = new Film(1,"sole","good film",st.parse(value),null,"Hindi", null, null,(byte)3,new Date(),(short) 120,new Date());
							List<Film> filmLisByReleaseYear=new ArrayList<Film>();
							filmLisByReleaseYear.add(film);
							Mockito.when(repo.searchFilmByReleaseYear((st.parse(value)))).thenReturn(filmLisByReleaseYear);
							
							assertEquals(null, service.searchFilmByReleaseYear((st.parse(value))));
						} catch (ParseException e) {
				
							e.printStackTrace();
						}
					
					}
					//test cases for delete film
					//1.If input is valid , should delete the film
					@Test
					public void deleteFilmsInputPresent(){
						Mockito.when(repo.remove(("sole"))).thenReturn(true);
						assertEquals("Film is delete", service.removeFilm("sole"));
					}
					//2. if film is not present,it should throw exception
					@Test
					public void deleteFilmInputNotPresent(){
						Mockito.when(repo.remove(("sole"))).thenReturn(false);
						assertEquals("film is not present", service.removeFilm("abc"));
					}
					//3. Even if value is present , it can't delete the film(system eroor)
					@Test(expected=Exception.class)
					public void deleteFilmSystemError(){
					Mockito.when(repo.remove("sole")).thenThrow(new Exception());
					service.removeFilm("sole");
					}
					//4.If input is null ,it should throw nullpointerexception
					@Test(expected =NullPointerException.class)
					public void deleteFilmInputIsNull(){
						service.removeFilm(null);
					}
					//test cases for modify film
					//1.If input is null,it should throw null pointer exception
					@Test(expected =NullPointerException.class)
					public void modifyFilmInputIsNull(){
						service.modifyFilm(null);
					}
					//2.when input is present but film is not present in system
					@Test
					public void modifyFilmInputIsNotPresent(){
						Film film=new Film();
						Mockito.when(repo.updateFilm((film))).thenReturn(false);
						assertEquals("Film is not updated", service.modifyFilm(film));
						}
					//3.when film is present ,system will modify the film
					@Test
					public void modifyFilmInputValidAndModifyIt(){
						Film film=new Film();
						Mockito.when(repo.updateFilm((film))).thenReturn(true);
						assertEquals("Film is updated", service.modifyFilm(film));
					}
					//4. Even if film is present , it can't modify the film(system eroor)
					@Test(expected=Exception.class)
					public void modifyFilmSystemError(){
						Film film=new Film();
						Mockito.when(repo.updateFilm(film)).thenThrow(new Exception());
						assertEquals("error", service.modifyFilm(film));
					}
}
